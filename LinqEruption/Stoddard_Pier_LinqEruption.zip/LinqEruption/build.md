## Create a console application for querying data using the data provided.

        dotnet new console (if !dir, dotnet console -o Xxx)

## Pull data from a data set (eruptions.cs) using LINQ queries.


## Verify correct data is pulled by rendering queried data to the console.

asdasd