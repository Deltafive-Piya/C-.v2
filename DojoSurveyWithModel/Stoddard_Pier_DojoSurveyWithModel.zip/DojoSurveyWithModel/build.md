dotnet new mvc --no-https -o DojoSurveyWithModel
cd DojoSurveyWithModel
code .

1) Create Model
    
2) Build form with Model (within Index.cshtml)

3) Post request

4) Results Page